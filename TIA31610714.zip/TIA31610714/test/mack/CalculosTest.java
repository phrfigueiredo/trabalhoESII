/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 31612520
 */
public class CalculosTest {

    public CalculosTest() {
    }

    /*
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
     */

    @Test
    public void testCalc() {
        Calculos c = new Calculos();
        int[] digitos = new int[8];
        digitos[0] = 3;
        digitos[1] = 1;
        digitos[2] = 6;
        digitos[3] = 1;
        digitos[4] = 0;
        digitos[5] = 7;
        digitos[6] = 1;
        digitos[7] = 4;
        assertEquals(23, c.calc(digitos, 1), 0.0);
        assertEquals(2, c.calc(digitos, 2), 0.0);
        assertEquals(7, c.calc(digitos, 3), 0.0);
        assertEquals(1, c.calc(digitos, 4), 0.0);
        assertEquals(1, c.calc(digitos, 5), 0.0);
        assertEquals(3, c.calc(digitos, 6), 0.0);
        assertEquals(5, c.calc(digitos, 7), 0.0);
        assertEquals(0.9166666865348816, c.calc(digitos, 8), 0.0);
        assertEquals(504, c.calc(digitos, 9), 0.0);
        assertEquals(72, c.calc(digitos, 10), 0.0);
        
        

    }

}
