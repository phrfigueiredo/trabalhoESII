
package mack;

import java.util.*;

/**
 *
 * @author 31612520
 */
public class Calculos {
    public float calc(int[] digitos, int modo) {  
        switch(modo){
            case 1:
                int soma = 0;
                for (int i = 0; i < digitos.length; i++) {
                    soma += digitos[i]; 
                }
                return soma;             
            case 2:
                int soma2 = 0;
                int media = 0;
                for (int i = 0; i < digitos.length; i++) {
                    soma2 += digitos[i]; 
                    media = soma2/digitos.length; 
                }
                return media;
                
            case 3:
                int maior = digitos[0];
                for (int i = 0; i < digitos.length; i++) {
                    if (maior < digitos[i]){
                        maior = digitos[i];
                    }
                    
                }return maior;
                
            case 4:
                int menor = digitos[0];
                for (int i = 0; i < digitos.length; i++) {
                    if (menor > digitos[i] && digitos[i] != 0){
                        menor = digitos[i];
                    }
                    
                }return menor;
            case 5:
                int lista[] = new int [10];
                for (int num : digitos) {
                    lista[num] += 1;
                }
                int saida = -1;
                int maior3 = 0;
                int posicao = 0;
                for (int i = 0; i < digitos.length; i++) {
                    if (lista[i] != 0){
                        if (lista[i] > maior3){
                            maior3 = lista[i];
                            posicao = i;
                        }
                    }
                    
                }
                if (maior3 > 0){
                    saida = posicao;
                }
                return saida;
                
                
            
            case 6:
                int pares = 0;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] % 2 == 0){
                        pares++;
                    }
                    
                }
                return pares;
            case 7:
                int impares = 0;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] % 2 != 0){
                        impares++;
                    }
                    
                }
                return impares;
            case 8:
                float fourPrim = 0;
                float fourUltim = 0;
                int metade = digitos.length / 2;
                
                for (int i = 0; i < digitos.length; i++) {
                    if (i <= metade){
                        fourPrim += digitos[i];
                    } else
                    {
                        fourUltim += digitos[i];
                    }
                    
                }
                return fourPrim / fourUltim;
                
            case 9:
                float produto = 1;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] != 0){
                        produto = digitos[i] * produto;
                    }
                    
                }return produto;
            case 10:
                int maior2 = digitos[0];
                for (int i = 0; i < digitos.length; i++) {
                    if (maior2 < digitos[i]){
                        maior2 = digitos[i];
                    }
                }
                float produto2 = 1;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] != 0 && digitos[i] != maior2){
                        produto2 = digitos[i] * produto2;
                    }
                    
                }return produto2;
                
        }
        return 0;
    }
}
    

